package com.chat.aerospike;

import com.aerospike.client.AerospikeClient;
import com.aerospike.client.Host;
import com.aerospike.client.policy.ClientPolicy;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;
import org.springframework.data.aerospike.config.AbstractAerospikeDataConfiguration;
import org.springframework.data.aerospike.repository.config.EnableAerospikeRepositories;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import java.util.Arrays;
import java.util.Collection;

@Configuration
@EnableAerospikeRepositories(basePackages = {"com.chat.repo"})
@EnableAutoConfiguration
@EnableTransactionManagement
public class AerospikeConfiguration extends AbstractAerospikeDataConfiguration {

    @Value("${aerospike.hosts}")
    private String aerospikeHosts;

    @Value("${aerospike.port}")
    private Integer aerospikePort;

    @Value("${aerospike.namespace}")
    private String aerospikeNamespace;

    @Bean(destroyMethod = "close")
    @Scope("singleton")
    @Override
    public AerospikeClient aerospikeClient() {

        ClientPolicy policy = new ClientPolicy();
        policy.failIfNotConnected = true;
        Collection<Host> hosts = getHosts();
        return new AerospikeClient(policy, hosts.toArray(new Host[hosts.size()]));
    }

    @Override
    protected Collection<Host> getHosts() {
        String[] hostList = aerospikeHosts.split(",");
        Host[] hosts = new Host[hostList.length];
        for(int i=0; i<hostList.length; i++){
            hosts[i] = new Host(hostList[i], aerospikePort);
        }
        return Arrays.asList(hosts);
    }

    @Override
    protected String nameSpace() {
        return aerospikeNamespace;
    }
}
