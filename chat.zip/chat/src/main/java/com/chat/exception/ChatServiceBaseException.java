package com.chat.exception;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonPropertyOrder(alphabetic = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ChatServiceBaseException extends Exception {
    private ExceptionDTO exception;

    public ChatServiceBaseException() {
    }

    /**
     * @param errorCode
     */
    public ChatServiceBaseException(String errorCode) {
        exception = new ExceptionDTO(errorCode);
    }

    /**
     * @param errorCode
     * @param errorMessage
     */
    public ChatServiceBaseException(String errorCode, String errorMessage) {
        super(errorMessage);
        exception = new ExceptionDTO(errorCode, errorMessage);
    }

    public ExceptionDTO getException() {
        return exception;
    }

    public void setException(ExceptionDTO exception) {
        this.exception = exception;
    }
}
