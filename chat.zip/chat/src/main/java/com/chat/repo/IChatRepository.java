package com.chat.repo;

import com.chat.entity.ChatmessagesCacheEntity;
import org.springframework.data.aerospike.repository.AerospikeRepository;

public interface IChatRepository extends AerospikeRepository<ChatmessagesCacheEntity, String> {
}
