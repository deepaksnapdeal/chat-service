package com.chat.utils;

import com.chat.common.model.CreateMessageRequestWrapper;
import com.chat.exception.ChatServiceBaseException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sun.istack.internal.NotNull;
import org.apache.commons.codec.DecoderException;
import org.apache.commons.codec.binary.Hex;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.Timer;
import java.util.zip.GZIPInputStream;

/**
 * Class to decompress LZMA compressed data received from UI.
 */
public class RequestDecompressionUtil {

    private static final Logger LOGGER = LoggerFactory.getLogger(RequestDecompressionUtil.class);

    /**
     *
     * @param objectMapper
     * @param createMessageRequestWrapper
     * @param clazz
     * @return
     * @throws ChatServiceBaseException
     */
    public static Object deCompressRequest(ObjectMapper objectMapper, CreateMessageRequestWrapper createMessageRequestWrapper, Class<?> clazz) throws ChatServiceBaseException {

        try {
            String data = createMessageRequestWrapper.data;
            Object returnVal = null;
            Timer timer = new Timer();
            if(createMessageRequestWrapper.compressed) {
                GZIPInputStream input = getByteArrayInputStream(createMessageRequestWrapper);
                returnVal = objectMapper.readValue(input, clazz);
            } else {
                returnVal = objectMapper.readValue(data, clazz);
            }
            LOGGER.debug("{} [Decompression_time] {} ms", clazz, timer.toString());
            return returnVal;
        } catch (IOException ioException) {
            LOGGER.error("Decode not available to decode request", ioException);
            throw new ChatServiceBaseException("COMPRESSION_ERROR", ioException.getMessage());
        } catch (DecoderException e) {
            LOGGER.error("Error in decompression", e);
            throw new ChatServiceBaseException("COMPRESSION_ERROR", e.getMessage());
        }
    }

    @NotNull
    private static GZIPInputStream getByteArrayInputStream(CreateMessageRequestWrapper requestWrapper) throws IOException, DecoderException {
        return new GZIPInputStream(new ByteArrayInputStream((Hex.decodeHex(requestWrapper.data.toCharArray()))));
    }

}
