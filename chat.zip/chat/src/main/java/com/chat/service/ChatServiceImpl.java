package com.chat.service;

import com.chat.common.model.CreateMessageRequest;
import com.chat.common.model.base.GetAllMessageRespose;
import com.chat.entity.ChatmessagesCacheEntity;
import com.chat.exception.ChatServiceBaseException;
import com.chat.repo.IChatRepository;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
public class ChatServiceImpl implements IChatService{

    private static final Logger LOGGER = LoggerFactory.getLogger(ChatServiceImpl.class);

    @Autowired
    private IChatRepository chatRepository;

    @Override
    public String saveMessage(CreateMessageRequest createMessageRequest, String userId) throws ChatServiceBaseException {
        try {
            UUID uuid = UUID.randomUUID();
            ChatmessagesCacheEntity chatmessagesCacheEntity = new ChatmessagesCacheEntity(uuid.toString(), createMessageRequest.getTimestamp(), createMessageRequest.getTextMessage(), userId);
            chatRepository.save(chatmessagesCacheEntity);
            return uuid.toString();
        } catch (Exception exe){
                LOGGER.error("Exception occurred while save messages", exe);
            throw  new ChatServiceBaseException(exe.getMessage());
        }
    }

    @Override
    public GetAllMessageRespose getAllMessage(String userId) {
        List<String> userIds = new ArrayList<>();
        userIds.add(userId);
        List<String> messages = new ArrayList<>();
        List<ChatmessagesCacheEntity> chatmessagesCacheEntities = (List<ChatmessagesCacheEntity>) chatRepository.findAllById(userIds);
        if (!CollectionUtils.isEmpty(chatmessagesCacheEntities)){
            messages = chatmessagesCacheEntities.stream().map(chatmessagesCacheEntitie -> chatmessagesCacheEntitie.getMessage()).collect(Collectors.toList());
        }
        GetAllMessageRespose allMessageRespose = new GetAllMessageRespose();
        allMessageRespose.setMesaages(messages);
        return allMessageRespose;
    }

    @Override
    public String deleteAllMessages(String userId) {
        List<String> userIds = new ArrayList<>();
        userIds.add(userId);
        chatRepository.deleteAllById(userIds);
        StringBuilder builder = new StringBuilder("All msg deleted for user id :: ");
        builder.append(userId);
        return builder.toString();
    }

    @Override
    public String deleteMessageByMessageId(String msgId) {
        boolean exist = chatRepository.existsById(msgId);
        if (exist){
            return StringUtils.EMPTY;
        }
        chatRepository.deleteById(msgId);
        StringBuilder builder = new StringBuilder("Msg deleted for id :: ");
        builder.append(msgId);
        return builder.toString();
    }


}
