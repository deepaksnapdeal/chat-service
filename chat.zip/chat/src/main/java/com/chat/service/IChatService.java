package com.chat.service;

import com.chat.common.model.CreateMessageRequest;
import com.chat.common.model.base.GetAllMessageRespose;
import com.chat.exception.ChatServiceBaseException;

public interface IChatService {
    String saveMessage(CreateMessageRequest createMessageRequest, String userId) throws ChatServiceBaseException;
    GetAllMessageRespose getAllMessage( String userId);
    String deleteAllMessages(String userId);
    String deleteMessageByMessageId(String msgId);
}
