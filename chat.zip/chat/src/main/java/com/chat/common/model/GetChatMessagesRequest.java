package com.chat.common.model;

import com.chat.common.model.base.ServiceRequest;

public class GetChatMessagesRequest extends ServiceRequest {
    private int limit = 10;
    private String startMessageId;

    public GetChatMessagesRequest() {
    }

    public int getLimit() {
        return limit;
    }

    public void setLimit(int limit) {
        this.limit = limit;
    }

    public String getStartMessageId() {
        return startMessageId;
    }

    public void setStartMessageId(String startMessageId) {
        this.startMessageId = startMessageId;
    }
}
