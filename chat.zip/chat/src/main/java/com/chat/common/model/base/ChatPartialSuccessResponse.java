package com.chat.common.model.base;

import com.chat.exception.ExceptionDTO;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonPropertyOrder(alphabetic = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ChatPartialSuccessResponse<T> extends ChatApiResponse<T> {
    public final T data;
    public ExceptionDTO exception;

    public ChatPartialSuccessResponse(T data) {
        super(Status.PARTIAL_SUCCESS);
        this.data = data;
    }

    public ChatPartialSuccessResponse(T data, String messageCode, String errorMessage) {
        super(Status.PARTIAL_SUCCESS);
        this.data = data;
        this.exception = new ExceptionDTO(messageCode, errorMessage);
    }

    public ChatPartialSuccessResponse() {
        super(Status.PARTIAL_SUCCESS);
        this.data = null;
        this.exception = null;
    }

    @JsonProperty("exception")
    public ExceptionDTO getException() {
        return exception;
    }

    public void setException(ExceptionDTO exception) {
        this.exception = exception;
    }

    public T getData() {
        return data;
    }
}