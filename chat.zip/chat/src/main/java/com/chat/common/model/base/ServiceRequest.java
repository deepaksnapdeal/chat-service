package com.chat.common.model.base;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.io.Serializable;

@JsonIgnoreProperties(
    ignoreUnknown = true
)
public abstract class ServiceRequest implements Serializable {
    private static final long serialVersionUID = -5519767113471859157L;
    private String userTrackingId;
    private RequestContextSRO contextSRO;

    public ServiceRequest() {
    }


    public String getUserTrackingId() {
        return this.userTrackingId;
    }

    public void setUserTrackingId(String userTrackingId) {
        this.userTrackingId = userTrackingId;
    }

    public RequestContextSRO getContextSRO() {
        return this.contextSRO;
    }

    public void setContextSRO(RequestContextSRO contextSRO) {
        this.contextSRO = contextSRO;
    }

    public String getUniqueLoggingCode() {
        return null;
    }
}