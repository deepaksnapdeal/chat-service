package com.chat.common.model.base;

import com.chat.exception.ExceptionDTO;
import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;


@EqualsAndHashCode(callSuper = true)
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
public class ChatFailureResponse<T> extends ChatApiResponse<T> {
    public T data;
    private ExceptionDTO exception;

    public ChatFailureResponse(String errorCode, String errorMessage) {
        this(new ExceptionDTO(errorCode, errorMessage));
    }

    public ChatFailureResponse(ExceptionDTO exception) {
        super(ChatApiResponse.Status.FAILURE);
        this.setSuccessful(false);
        this.exception = exception;
    }

    public ChatFailureResponse(T data) {
        super(ChatApiResponse.Status.FAILURE);
        this.setSuccessful(false);
        this.data = data;
    }

    public ChatFailureResponse() {
        super(ChatApiResponse.Status.FAILURE);
    }

    public ChatFailureResponse(T data, String messageCode, String errorMessage) {
        super(ChatApiResponse.Status.FAILURE);
        this.data = data;
        this.setSuccessful(false);
        this.exception = new ExceptionDTO(messageCode, errorMessage);
    }

    @JsonProperty("exception")
    public ExceptionDTO getException() {
        return exception;
    }

}