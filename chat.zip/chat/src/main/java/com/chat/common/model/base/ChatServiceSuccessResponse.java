package com.chat.common.model.base;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonPropertyOrder(alphabetic = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ChatServiceSuccessResponse<T> extends ChatApiResponse<T> {
    private static final long serialVersionUID = 6097186825549951545L;
    public final T data;

    public ChatServiceSuccessResponse(T data) {
        super(Status.SUCCESS);
        this.data = data;
    }

    public ChatServiceSuccessResponse() {
        super(Status.SUCCESS);
        this.data = null;
    }
}