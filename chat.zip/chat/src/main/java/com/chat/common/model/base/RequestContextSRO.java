package com.chat.common.model.base;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.io.Serializable;

@JsonIgnoreProperties(
    ignoreUnknown = true
)
public class RequestContextSRO implements Serializable {
    private static final long serialVersionUID = -4788606633051950734L;
    private String requestId;
    private String appIdent;
    private String appIP;

    private String apiVariantId;

    private String locale;

    public RequestContextSRO() {
    }

    public String getRequestId() {
        return this.requestId;
    }

    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    public String getAppIdent() {
        return this.appIdent;
    }

    public void setAppIdent(String appIdent) {
        this.appIdent = appIdent;
    }

    public String getAppIP() {
        return this.appIP;
    }

    public void setAppIP(String appIP) {
        this.appIP = appIP;
    }

    public String getApiVariantId() {
        return this.apiVariantId;
    }

    public void setApiVariantId(String apiVariantId) {
        this.apiVariantId = apiVariantId;
    }

    public String getLocale() {
        return this.locale;
    }

    public void setLocale(String locale) {
        this.locale = locale;
    }

    @JsonIgnore
    public RequestContextSRO getCopy() {
        RequestContextSRO context = new RequestContextSRO();
        context.setRequestId(this.getRequestId());
        context.setAppIP(this.getAppIP());
        context.setAppIdent(this.getAppIdent());
        context.setApiVariantId(this.getApiVariantId());
        context.setLocale(this.getLocale());
        return context;
    }

    public String toString() {
        return String.format("[requestId=%s|appIdent=%s|appIP=%s|apiVariantId=%s|locale=%s]", this.requestId, this.appIdent, this.appIP, this.apiVariantId, this.locale);
    }
}