package com.chat.common.model.base;

public class DeleteMessageRespose extends ServiceResponse{
    private String message;

    public DeleteMessageRespose() {
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
