package com.chat.common.model;

import com.chat.common.model.base.ServiceRequest;

public class CreateMessageRequest extends ServiceRequest {
    private String textMessage;

    private long timestamp;

    private boolean isSent;


    public CreateMessageRequest() {
    }

    public String getTextMessage() {
        return textMessage;
    }

    public void setTextMessage(String textMessage) {
        this.textMessage = textMessage;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }

    public boolean isSent() {
        return isSent;
    }

    public void setSent(boolean sent) {
        isSent = sent;
    }
}
