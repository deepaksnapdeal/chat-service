package com.chat.common.model.base;

import java.util.List;

public class GetAllMessageRespose extends ServiceResponse {
    List<String> mesaages;

    public GetAllMessageRespose() {
    }



    public List<String> getMesaages() {
        return mesaages;
    }

    public void setMesaages(List<String> mesaages) {
        this.mesaages = mesaages;
    }
}
