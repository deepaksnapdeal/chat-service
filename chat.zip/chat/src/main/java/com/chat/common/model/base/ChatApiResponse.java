package com.chat.common.model.base;

import com.fasterxml.jackson.annotation.*;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;



@JsonTypeInfo(use = JsonTypeInfo.Id.NAME, include = JsonTypeInfo.As.PROPERTY, property = "status")
@JsonSubTypes({
        @JsonSubTypes.Type(value = ChatServiceSuccessResponse.class, name = "SUCCESS"),
        @JsonSubTypes.Type(value = ChatFailureResponse.class, name = "FAILURE"),
        @JsonSubTypes.Type(value = ChatPartialSuccessResponse.class, name = "PARTIAL_SUCCESS"),
        @JsonSubTypes.Type(value = ChatPartialSuccessResponse.class, name = "FAILURE")})

@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder(alphabetic = true)
public class ChatApiResponse<T> extends ServiceResponse implements Serializable {
    private static final long serialVersionUID = 3515865622045372904L;
    @JsonIgnore
    public final Status status;

    public ChatApiResponse() {
        this(Status.FAILURE);
    }

    public ChatApiResponse(Status status) {
        this.status = status;
    }

    public Status getStatus() {
        return status;
    }

    public enum Status {
        @SerializedName("SUCCESS")
        SUCCESS,

        @SerializedName("FAILURE")
        FAILURE,

        @SerializedName("PARTIAL_SUCCESS")
        PARTIAL_SUCCESS
    }
}