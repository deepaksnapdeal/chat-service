package com.chat.common.model.base;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.io.Serializable;

@JsonIgnoreProperties(
    ignoreUnknown = true
)
public class ServiceResponse implements Serializable {
    private static final long serialVersionUID = -7608591897563945814L;
    private boolean successful = true;
    private String code;
    private String message;


    public ServiceResponse() {
    }

    /** @deprecated */
    public ServiceResponse(boolean successful, String message) {
        this.successful = successful;
        this.message = message;
    }

    public ServiceResponse(String code, String message) {
        this.code = code;
        this.message = message;
    }

    public ServiceResponse(String code) {
        this.code = code;
    }

    /** @deprecated */
    public boolean isSuccessful() {
        return this.successful;
    }

    /** @deprecated */
    public void setSuccessful(boolean successful) {
        this.successful = successful;
    }

    public String getCode() {
        return this.code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMessage() {
        return this.message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}