package com.chat.common.model;

import com.chat.common.model.base.ServiceResponse;

public class CreateMessageResponse extends ServiceResponse {
    protected static final long serialVersionUID = 1L;

    private String messageID;

    public CreateMessageResponse() {
        super();
    }

    public String getMessageID() {
        return messageID;
    }

    public void setMessageID(String messageID) {
        this.messageID = messageID;
    }
}