package com.chat.controller;

import com.chat.common.model.CreateMessageRequest;
import com.chat.common.model.CreateMessageRequestWrapper;
import com.chat.common.model.CreateMessageResponse;
import com.chat.common.model.base.*;
import com.chat.exception.ChatServiceBaseException;
import com.chat.service.IChatService;
import com.chat.utils.RequestDecompressionUtil;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

@Controller
public class ChatController {
    private static final Logger LOGGER = LoggerFactory.getLogger(ChatController.class);

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private IChatService chatService;

    @ResponseBody
    @PostMapping(path = "/chatlogs/{user}/")
    public ChatApiResponse<CreateMessageResponse> createMessage(@PathVariable("user") String userId, @RequestBody CreateMessageRequestWrapper request) {

        try {
            CreateMessageRequest createMessageRequest = (CreateMessageRequest) RequestDecompressionUtil.deCompressRequest(objectMapper, request, CreateMessageRequest.class);
            String msgId = chatService.saveMessage(createMessageRequest, userId);
            CreateMessageResponse createMessageResponse = new CreateMessageResponse();
            createMessageResponse.setMessageID(msgId);
            return new ChatServiceSuccessResponse<>(createMessageResponse);
        } catch (ChatServiceBaseException e) {
            return new ChatFailureResponse<>(e.getException());
        }

    }

    @ResponseBody
    @GetMapping(path = "/chatlogs/{user}/")
    public ChatApiResponse<GetAllMessageRespose> getChatMessages(@PathVariable("user") String userId, @RequestBody CreateMessageResponse request) {
        GetAllMessageRespose allMessageRespose = chatService.getAllMessage(userId);
        return new ChatServiceSuccessResponse<>(allMessageRespose);

    }

    @ResponseBody
    @DeleteMapping(path = "/chatlogs/{user}/")
    public ChatApiResponse<String> deleteAllMessages(@PathVariable("user") String userId) {

        String  response = chatService.deleteAllMessages(userId);
        return new ChatServiceSuccessResponse<>(response);

    }

    @ResponseBody
    @DeleteMapping(path = "/chatlogs/{user}/{msgid}")
    public ChatApiResponse<DeleteMessageRespose> deleteMessage(@PathVariable("user") String userId, @PathVariable("msgid") String msgid) {
        String  response = chatService.deleteMessageByMessageId(msgid);
        DeleteMessageRespose deleteMessageRespose = new DeleteMessageRespose();
        if (StringUtils.isEmpty(response)){
            deleteMessageRespose.setCode(String.valueOf(HttpStatus.NOT_FOUND));
            deleteMessageRespose.setMessage(HttpStatus.NOT_FOUND.getReasonPhrase());
        } else {
            deleteMessageRespose.setCode(String.valueOf(HttpStatus.OK));
            deleteMessageRespose.setMessage(response);
        }
        return new ChatServiceSuccessResponse<>(deleteMessageRespose);
    }

}
