package com.chat.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import org.springframework.data.aerospike.mapping.Document;
import org.springframework.data.annotation.Id;

import java.util.concurrent.TimeUnit;

@Data
@AllArgsConstructor
@Document(collection = "chatmessagesCacheEntity", touchOnRead = true, expirationExpression = "${chatmessagesCacheEntity.ttl}", expirationUnit = TimeUnit.SECONDS)
public class ChatmessagesCacheEntity {
    @Id
    private String messageId;
    private long timeStamp ;
    private String message;
    private String userId;

    public ChatmessagesCacheEntity(String userId) {
        this.userId = userId;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}