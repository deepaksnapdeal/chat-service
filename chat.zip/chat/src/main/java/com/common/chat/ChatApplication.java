package com.common.chat;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.PropertySource;
@EnableCaching
@SpringBootApplication(scanBasePackages = {"com.chat.*"}, exclude={SecurityAutoConfiguration.class})
@PropertySource("file:/Users/deepak.kumar09/projects/chat/src/main/resources/localConf/app.properties")
@ComponentScan(basePackages = {"com.chat.*"})
public class ChatApplication {

	public static void main(String[] args) {
		SpringApplication.run(ChatApplication.class, args);
	}

}
